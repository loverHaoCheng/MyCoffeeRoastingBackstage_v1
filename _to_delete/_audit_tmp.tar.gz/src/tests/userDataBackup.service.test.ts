import { afterEach, describe, expect, it, vi } from 'vitest';

import { userDataBackupService, type UserDataBackupFile } from '@/modules/settings/services/userDataBackup.service';
import { AppError } from '@/shared/errors/AppError';
import { PocketBaseRestClient } from '@/services/pocketBaseRestClient';
import { pocketBaseSessionService } from '@/services/pocketBaseSession.service';

const backupCollectionNames = [
  'green_beans',
  'green_bean_purchase_batches',
  'bean_sale_specs',
  'roasting_machines',
  'roast_profiles',
  'roast_batches',
  'roast_curve_records',
  'roast_records',
  'ai_roast_consents',
  'ai_roast_profiles',
  'ai_roast_reviews',
  'ai_roast_recommendations',
  'ai_roast_feedback',
  'finance_expense_records',
  'finance_income_records',
  'cost_calculations',
  'app_settings',
] as const;

describe('userDataBackupService', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    pocketBaseSessionService.clear();
  });

  it('rejects backup files larger than the import limit before reading them', async () => {
    const file = new File(['{}'], 'oversized.json', { type: 'application/json' });
    Object.defineProperty(file, 'size', { value: 20 * 1024 * 1024 + 1 });

    await expect(userDataBackupService.readBackupFile(file)).rejects.toMatchObject({
      message: '备份文件超过 20MB，请拆分数据后重试。',
    });
  });

  it('keeps exporting when an optional backup collection is not initialized', async () => {
    const missingCollectionError = new AppError('PocketBase 记录或集合不存在，请先执行初始化。', {
      code: 'HTTP',
      status: 404,
    });

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        if (collectionName === 'roast_records') {
          throw missingCollectionError;
        }

        return Promise.resolve([{ id: `${collectionName}-1` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.createBackup()).resolves.toMatchObject({
      collections: {
        roast_records: [],
      },
      summary: {
        roast_records: 0,
      },
    });
  });

  it('keeps exporting when a production environment does not expose optional AI backup collections', async () => {
    const forbiddenCollectionError = new AppError('集合未开放访问。', {
      code: 'AUTH',
      status: 403,
    });

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        if (collectionName === 'ai_roast_reviews') {
          throw forbiddenCollectionError;
        }

        return Promise.resolve([{ id: `${collectionName}-1` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.createBackup()).resolves.toMatchObject({
      collections: {
        ai_roast_reviews: [],
      },
      summary: {
        ai_roast_reviews: 0,
      },
    });
  });

  it('retries backup export without sorting when a legacy collection rejects the created_at sort', async () => {
    const sortError = new AppError('PocketBase 请求失败，请稍后重试或联系管理员检查服务日志。（HTTP 400）', {
      code: 'HTTP',
      status: 400,
    });
    const listSpy = vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string, options?: { orderBy?: unknown }): Promise<TOutput[]> => {
        if (collectionName === 'green_beans' && options?.orderBy) {
          throw sortError;
        }

        return Promise.resolve([{ id: `${collectionName}-1` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.createBackup()).resolves.toMatchObject({
      collections: {
        green_beans: [{ id: 'green_beans-1' }],
      },
      summary: {
        green_beans: 1,
      },
    });
    expect(listSpy).toHaveBeenCalledWith('green_beans', expect.objectContaining({
      orderBy: {
        ascending: true,
        column: 'created_at',
      },
    }));
    expect(listSpy).toHaveBeenCalledWith('green_beans', {
      limit: 10_000,
    });
  });

  it('regenerates ids and rewrites relations when importing an old account backup into a new account', async () => {
    const generatedIds: Record<string, string> = {
      app_settings: 'setting-new',
      green_beans: 'bean-new',
      roast_batches: 'batch-new',
      roast_curve_records: 'curve-new',
      roast_profiles: 'plan-new',
      roasting_machines: 'machine-new',
    };
    const backup: UserDataBackupFile = {
      collections: {
        app_settings: [
          {
            id: 'setting-old',
            key: 'green_bean_sale_defaults:bean-old',
            owner: 'old-user',
            value: { defaultSaleUnitPrice: 88 },
          },
        ],
        green_beans: [
          {
            id: 'bean-old',
            display_name: 'Guji',
            owner: 'old-user',
          },
        ],
        roast_batches: [
          {
            id: 'batch-old',
            green_bean_id: 'bean-old',
            roast_plan_id: 'plan-old',
          },
        ],
        roast_curve_records: [
          {
            id: 'curve-old',
            roast_batch_id: 'batch-old',
          },
        ],
        roast_profiles: [
          {
            id: 'plan-old',
            green_bean_id: 'bean-old',
            name: 'Plan',
            roaster_machine_id: 'machine-old',
          },
        ],
        roasting_machines: [
          {
            id: 'machine-old',
            display_name: 'Tank200D',
            model_id: 'model-old',
            model_key: 'tank200d',
            owner: 'old-user',
            status: 'active',
          },
        ],
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        return Promise.resolve([{ id: generatedIds[collectionName] ?? `${collectionName}-new` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 6,
      skipped: 0,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('green_beans', expect.not.objectContaining({
      id: 'bean-old',
      owner: 'old-user',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roasting_machines', expect.objectContaining({
      display_name: 'Tank200D',
      model_key: 'tank200d',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roasting_machines', expect.not.objectContaining({
      model_id: 'model-old',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.objectContaining({
      green_bean_id: 'bean-new',
      roaster_machine_id: 'machine-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_batches', expect.objectContaining({
      green_bean_id: 'bean-new',
      roast_plan_id: 'plan-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_curve_records', expect.objectContaining({
      roast_batch_id: 'batch-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('app_settings', expect.objectContaining({
      key: 'green_bean_sale_defaults:bean-new',
      value: { defaultSaleUnitPrice: 88 },
    }));
  });

  it('keeps same-code beans separate across accounts and links purchase batches to the imported bean id', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_bean_purchase_batches: [
          {
            id: 'purchase-old',
            green_bean_id: 'bean-old',
            purchased_weight_grams: 1000,
            remaining_weight_grams: 1000,
          },
        ],
        green_beans: [
          {
            id: 'bean-old',
            code: 'GB-001',
            display_name: '重复生豆',
            owner: 'old-user',
          },
        ],
      },
      exportedBy: {
        email: 'old@example.com',
        id: 'old-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    const listSpy = vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        if (collectionName === 'green_beans') {
          return Promise.resolve([{ id: 'bean-imported' }] as TOutput[]);
        }

        return Promise.resolve([{ id: `${collectionName}-new`, ...payload }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 2,
      skipped: 0,
      updated: 0,
    });

    expect(listSpy).not.toHaveBeenCalled();
    expect(insertSpy).toHaveBeenCalledWith('green_beans', expect.not.objectContaining({
      id: 'bean-old',
      owner: 'old-user',
    }));
    expect(listSpy).not.toHaveBeenCalledWith('green_beans', expect.objectContaining({
      match: {
        code: 'GB-001',
      },
    }));
    expect(insertSpy).toHaveBeenCalledWith('green_bean_purchase_batches', expect.objectContaining({
      green_bean_id: 'bean-imported',
      purchased_weight_grams: 1000,
      remaining_weight_grams: 1000,
    }));
  });

  it('includes the current purchase batch version when fully synchronizing a same-account backup', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_bean_purchase_batches: [{
          id: 'purchase-1',
          owner: 'current-user',
          purchased_weight_grams: 1000,
          remaining_weight_grams: 800,
        }],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-26T12:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string, options?: { match?: Record<string, unknown> }): Promise<TOutput[]> => {
        if (collectionName === 'green_bean_purchase_batches' && options?.match?.id === 'purchase-1') {
          return Promise.resolve([{ id: 'purchase-1', updated_at: '2026-07-26T12:01:00.000Z' }] as TOutput[]);
        }

        return Promise.resolve([]);
      },
    );
    const updateSpy = vi.spyOn(PocketBaseRestClient.prototype, 'update').mockResolvedValue([]);

    await expect(userDataBackupService.importBackup(backup, { strategy: 'sync' })).resolves.toEqual({
      deleted: 0,
      imported: 0,
      skipped: 0,
      updated: 1,
    });

    expect(updateSpy).toHaveBeenCalledWith(
      'green_bean_purchase_batches',
      expect.objectContaining({
        __expected_updated_at: '2026-07-26T12:01:00.000Z',
        remaining_weight_grams: 800,
      }),
      expect.objectContaining({
        match: { id: 'purchase-1' },
      }),
    );
  });

  it('supplements same-account backups by id instead of merging beans with the same code', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_beans: [
          {
            id: 'bean-from-backup',
            code: 'GB-001',
            display_name: '同号补缺生豆',
            owner: 'current-user',
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    const listSpy = vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string, options?: { match?: Record<string, unknown> }): Promise<TOutput[]> => {
        if (collectionName === 'green_beans' && options?.match?.id === 'bean-from-backup') {
          return Promise.resolve([]);
        }

        if (collectionName === 'green_beans' && options?.match?.code === 'GB-001') {
          return Promise.resolve([{ id: 'bean-current', code: 'GB-001' }] as TOutput[]);
        }

        return Promise.resolve([]);
      },
    );
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        return Promise.resolve([{ id: payload.id }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 1,
      skipped: 0,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('green_beans', expect.objectContaining({
      code: 'GB-001',
      display_name: '同号补缺生豆',
      id: 'bean-from-backup',
    }));
    expect(listSpy).not.toHaveBeenCalledWith('green_beans', expect.objectContaining({
      match: {
        code: 'GB-001',
      },
    }));
  });

  it('skips existing same-account records by PocketBase id and keeps their relation mapping', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_bean_purchase_batches: [
          {
            id: 'purchase-from-backup',
            green_bean_id: 'bean-existing',
            owner: 'current-user',
            purchased_weight_grams: 1000,
          },
        ],
        green_beans: [
          {
            id: 'bean-existing',
            code: 'GB-001',
            owner: 'current-user',
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string, options?: { match?: Record<string, unknown> }): Promise<TOutput[]> => {
        if (collectionName === 'green_beans' && options?.match?.id === 'bean-existing') {
          return Promise.resolve([{ id: 'bean-existing' }] as TOutput[]);
        }

        return Promise.resolve([]);
      },
    );
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        return Promise.resolve([{ id: payload.id }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 1,
      skipped: 1,
      updated: 0,
    });

    expect(insertSpy).not.toHaveBeenCalledWith('green_beans', expect.anything());
    expect(insertSpy).toHaveBeenCalledWith('green_bean_purchase_batches', expect.objectContaining({
      green_bean_id: 'bean-existing',
      id: 'purchase-from-backup',
      purchased_weight_grams: 1000,
    }));
  });

  it('continues importing app settings with a regenerated id after a same-account duplicate id conflict', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const duplicateIdError = new AppError('提交失败：id已存在，请更换后重试', {
      code: 'HTTP',
      status: 400,
    });
    const backup: UserDataBackupFile = {
      collections: {
        app_settings: [
          {
            id: 'setting-existing',
            key: 'green_bean_grade:bean-existing',
            owner: 'current-user',
            value: { grade: 'G1' },
          },
          {
            id: 'setting-cost-template',
            key: 'cost_template_settings',
            owner: 'current-user',
            value: {
              defaultTemplateId: 'template-1',
              templates: [
                {
                  createdAt: '2026-07-15T08:00:00.000Z',
                  defaultBakeWeight: 1000,
                  dehydrationRate: 15,
                  energyCost: 2,
                  id: 'template-1',
                  laborCost: 5,
                  name: '默认成本模板',
                  otherCost: 0,
                  packagingCost: 1,
                  targetProfitRate: 30,
                  unitWeightGrams: 100,
                },
              ],
              updatedAt: '2026-07-15T08:00:00.000Z',
            },
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        if (payload.id === 'setting-existing') {
          throw duplicateIdError;
        }

        return Promise.resolve([{ id: typeof payload.id === 'string' ? payload.id : 'setting-regenerated' }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 2,
      skipped: 0,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('app_settings', expect.not.objectContaining({
      id: 'setting-existing',
      owner: 'current-user',
    }));
    expect(insertSpy).toHaveBeenCalledWith('app_settings', expect.objectContaining({
      id: 'setting-cost-template',
      key: 'cost_template_settings',
    }));
  });

  it('supplements missing same-account app settings instead of treating write validation errors as optional collection gaps', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        app_settings: [
          {
            created_at: '2026-07-15T08:00:00.000Z',
            id: 'setting-cost-template',
            key: 'cost_template_settings',
            owner: 'current-user',
            updated_at: '2026-07-15T08:10:00.000Z',
            value: {
              defaultTemplateId: 'template-1',
              templates: [
                {
                  createdAt: '2026-07-15T08:00:00.000Z',
                  defaultBakeWeight: 1000,
                  dehydrationRate: 15,
                  energyCost: 2,
                  id: 'template-1',
                  laborCost: 5,
                  name: '默认成本模板',
                  otherCost: 0,
                  packagingCost: 1,
                  targetProfitRate: 30,
                  unitWeightGrams: 100,
                },
              ],
              updatedAt: '2026-07-15T08:10:00.000Z',
            },
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        return Promise.resolve([{ id: payload.id }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 1,
      skipped: 0,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('app_settings', expect.objectContaining({
      id: 'setting-cost-template',
      key: 'cost_template_settings',
    }));
    expect(insertSpy).toHaveBeenCalledWith('app_settings', expect.not.objectContaining({
      created_at: '2026-07-15T08:00:00.000Z',
      owner: 'current-user',
      updated_at: '2026-07-15T08:10:00.000Z',
    }));
  });

  it('surfaces non-collection app settings write errors during import', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const validationError = new AppError('提交失败：value不能为空', {
      code: 'HTTP',
      status: 400,
    });
    const backup: UserDataBackupFile = {
      collections: {
        app_settings: [
          {
            id: 'setting-invalid',
            key: 'cost_template_settings',
            owner: 'current-user',
            value: null,
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockRejectedValue(validationError);

    await expect(userDataBackupService.importBackup(backup)).rejects.toThrow('value不能为空');
  });

  it('fully syncs same-account backups by deleting extras, updating matches, and inserting missing records', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_beans: [
          {
            id: 'bean-a',
            display_name: '正式端生豆 A',
            owner: 'current-user',
          },
          {
            id: 'bean-c',
            display_name: '正式端新增生豆 C',
            owner: 'current-user',
          },
        ],
      },
      exportedBy: {
        email: 'current@example.com',
        id: 'current-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockImplementation(
      <TOutput,>(collectionName: string, options?: { match?: Record<string, unknown> }): Promise<TOutput[]> => {
        if (collectionName === 'green_beans' && !options?.match) {
          return Promise.resolve([{ id: 'bean-a' }, { id: 'bean-b' }] as TOutput[]);
        }

        if (collectionName === 'green_beans' && options?.match?.id === 'bean-a') {
          return Promise.resolve([{ id: 'bean-a' }] as TOutput[]);
        }

        return Promise.resolve([]);
      },
    );
    const deleteSpy = vi.spyOn(PocketBaseRestClient.prototype, 'delete').mockResolvedValue(undefined);
    const updateSpy = vi.spyOn(PocketBaseRestClient.prototype, 'update').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        return Promise.resolve([{ id: 'bean-a', ...payload }] as TOutput[]);
      },
    );
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(_collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        return Promise.resolve([{ id: payload.id }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup, { strategy: 'sync' })).resolves.toEqual({
      deleted: 1,
      imported: 1,
      skipped: 0,
      updated: 1,
    });

    expect(deleteSpy).toHaveBeenCalledWith('green_beans', {
      match: {
        id: 'bean-b',
      },
    });
    expect(updateSpy).toHaveBeenCalledWith('green_beans', expect.objectContaining({
      display_name: '正式端生豆 A',
    }), expect.objectContaining({
      match: {
        id: 'bean-a',
      },
    }));
    expect(updateSpy).toHaveBeenCalledWith('green_beans', expect.not.objectContaining({
      id: 'bean-a',
      owner: 'current-user',
    }), expect.anything());
    expect(insertSpy).toHaveBeenCalledWith('green_beans', expect.objectContaining({
      display_name: '正式端新增生豆 C',
      id: 'bean-c',
    }));
  });

  it('applies the cross-account id regeneration strategy to every backup collection', async () => {
    pocketBaseSessionService.save({
      user: {
        email: 'current@example.com',
        id: 'current-user',
      },
    });
    const collections: UserDataBackupFile['collections'] = {
      app_settings: [{ id: 'app_settings-old', key: 'cost_template_settings', owner: 'old-user', value: {} }],
      ai_roast_consents: [{ id: 'ai_roast_consents-old', owner: 'old-user' }],
      ai_roast_feedback: [{ id: 'ai_roast_feedback-old', owner: 'old-user' }],
      ai_roast_profiles: [{ id: 'ai_roast_profiles-old', owner: 'old-user' }],
      ai_roast_recommendations: [{ id: 'ai_roast_recommendations-old', owner: 'old-user' }],
      ai_roast_reviews: [{ id: 'ai_roast_reviews-old', owner: 'old-user' }],
      bean_sale_specs: [{ id: 'bean_sale_specs-old', owner: 'old-user' }],
      cost_calculations: [{ id: 'cost_calculations-old', owner: 'old-user' }],
      finance_expense_records: [{ id: 'finance_expense_records-old', owner: 'old-user' }],
      finance_income_records: [{ id: 'finance_income_records-old', owner: 'old-user' }],
      green_bean_purchase_batches: [{ id: 'green_bean_purchase_batches-old', owner: 'old-user' }],
      green_beans: [{ id: 'green_beans-old', owner: 'old-user' }],
      roast_batches: [{ id: 'roast_batches-old', owner: 'old-user' }],
      roast_curve_records: [{ id: 'roast_curve_records-old', owner: 'old-user' }],
      roast_profiles: [{ id: 'roast_profiles-old', owner: 'old-user' }],
      roast_records: [{ id: 'roast_records-old', owner: 'old-user' }],
      roasting_machines: [{ id: 'roasting_machines-old', owner: 'old-user' }],
    };
    const backup: UserDataBackupFile = {
      collections,
      exportedBy: {
        email: 'old@example.com',
        id: 'old-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    const listSpy = vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        return Promise.resolve([{ id: `${collectionName}-new` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: backupCollectionNames.length,
      skipped: 0,
      updated: 0,
    });

    expect(listSpy).not.toHaveBeenCalled();
    backupCollectionNames.forEach((collectionName) => {
      expect(insertSpy).toHaveBeenCalledWith(collectionName, expect.not.objectContaining({
        id: `${collectionName}-old`,
        owner: 'old-user',
      }));
    });
  });

  it('rewrites AI roast backup references to imported machine, batch, curve, and recommendation ids', async () => {
    const generatedIds: Record<string, string> = {
      ai_roast_feedback: 'feedback-new',
      ai_roast_recommendations: 'recommendation-new',
      ai_roast_reviews: 'review-new',
      roast_batches: 'batch-new',
      roast_curve_records: 'curve-new',
      roasting_machines: 'machine-new',
    };
    const backup: UserDataBackupFile = {
      collections: {
        ai_roast_feedback: [
          {
            id: 'feedback-old',
            owner: 'old-user',
            recommendation_id: 'recommendation-old',
            roast_batch_id: 'batch-old',
          },
        ],
        ai_roast_recommendations: [
          {
            id: 'recommendation-old',
            machine_id: 'machine-old',
            owner: 'old-user',
          },
        ],
        ai_roast_reviews: [
          {
            curve_record_id: 'curve-old',
            id: 'review-old',
            machine_id: 'machine-old',
            owner: 'old-user',
            roast_batch_id: 'batch-old',
          },
        ],
        roast_batches: [
          {
            id: 'batch-old',
            owner: 'old-user',
          },
        ],
        roast_curve_records: [
          {
            id: 'curve-old',
            owner: 'old-user',
            roast_batch_id: 'batch-old',
          },
        ],
        roasting_machines: [
          {
            id: 'machine-old',
            owner: 'old-user',
          },
        ],
      },
      exportedBy: {
        email: 'old@example.com',
        id: 'old-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        return Promise.resolve([{ id: generatedIds[collectionName] ?? `${collectionName}-new` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 6,
      skipped: 0,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('ai_roast_reviews', expect.objectContaining({
      curve_record_id: 'curve-new',
      machine_id: 'machine-new',
      roast_batch_id: 'batch-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('ai_roast_recommendations', expect.objectContaining({
      machine_id: 'machine-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('ai_roast_feedback', expect.objectContaining({
      recommendation_id: 'recommendation-new',
      roast_batch_id: 'batch-new',
    }));
  });

  it('imports the core backup data when production skips unavailable roasting machine and AI collections', async () => {
    const unavailableCollectionError = new AppError('集合未开放访问。', {
      code: 'AUTH',
      status: 403,
    });
    const backup: UserDataBackupFile = {
      collections: {
        ai_roast_recommendations: [
          {
            id: 'recommendation-old',
            machine_id: 'machine-old',
            owner: 'old-user',
          },
        ],
        green_beans: [
          {
            id: 'bean-old',
            owner: 'old-user',
          },
        ],
        roast_profiles: [
          {
            green_bean_id: 'bean-old',
            id: 'plan-old',
            owner: 'old-user',
            roaster_machine_id: 'machine-old',
          },
        ],
        roasting_machines: [
          {
            display_name: 'Tank200D',
            id: 'machine-old',
            owner: 'old-user',
          },
        ],
      },
      exportedBy: {
        email: 'old@example.com',
        id: 'old-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string): Promise<TOutput[]> => {
        if (collectionName === 'ai_roast_recommendations' || collectionName === 'roasting_machines') {
          throw unavailableCollectionError;
        }

        return Promise.resolve([{ id: `${collectionName}-new` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 2,
      skipped: 2,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.objectContaining({
      green_bean_id: 'green_beans-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.not.objectContaining({
      roaster_machine_id: 'machine-old',
    }));
  });

  it('retries roast profile import with legacy roaster_model when production still requires it', async () => {
    const unavailableCollectionError = new AppError('集合未开放访问。', {
      code: 'AUTH',
      status: 403,
    });
    const missingRoasterModelError = new AppError('提交失败：roaster_model不能为空', {
      code: 'HTTP',
      status: 400,
    });
    const backup: UserDataBackupFile = {
      collections: {
        green_beans: [
          {
            id: 'bean-old',
            owner: 'old-user',
          },
        ],
        roast_profiles: [
          {
            green_bean_id: 'bean-old',
            id: 'plan-old',
            owner: 'old-user',
            roaster_machine_id: 'machine-old',
          },
        ],
        roasting_machines: [
          {
            display_name: 'Tank200D',
            id: 'machine-old',
            model_key: 'tank200d',
            owner: 'old-user',
          },
        ],
      },
      exportedBy: {
        email: 'old@example.com',
        id: 'old-user',
      },
      exportedAt: '2026-07-15T08:00:00.000Z',
      schema: 'easybake.user-data-backup',
      summary: {},
      version: 1,
    };
    let roastProfileAttempts = 0;

    vi.spyOn(PocketBaseRestClient.prototype, 'list').mockResolvedValue([]);
    const insertSpy = vi.spyOn(PocketBaseRestClient.prototype, 'insert').mockImplementation(
      <TOutput,>(collectionName: string, payload: Record<string, unknown>): Promise<TOutput[]> => {
        if (collectionName === 'roasting_machines') {
          throw unavailableCollectionError;
        }

        if (collectionName === 'roast_profiles') {
          roastProfileAttempts += 1;

          if (roastProfileAttempts === 1) {
            throw missingRoasterModelError;
          }

          return Promise.resolve([{ id: 'plan-new', ...payload }] as TOutput[]);
        }

        return Promise.resolve([{ id: `${collectionName}-new` }] as TOutput[]);
      },
    );

    await expect(userDataBackupService.importBackup(backup)).resolves.toEqual({
      deleted: 0,
      imported: 2,
      skipped: 1,
      updated: 0,
    });

    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.objectContaining({
      green_bean_id: 'green_beans-new',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.objectContaining({
      roaster_model: 'Tank200D',
    }));
    expect(insertSpy).toHaveBeenCalledWith('roast_profiles', expect.not.objectContaining({
      roaster_machine_id: 'machine-old',
    }));
  });
});
