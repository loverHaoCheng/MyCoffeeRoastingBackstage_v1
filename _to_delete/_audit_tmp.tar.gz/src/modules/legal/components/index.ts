export { LegalFooter } from './LegalFooter';
