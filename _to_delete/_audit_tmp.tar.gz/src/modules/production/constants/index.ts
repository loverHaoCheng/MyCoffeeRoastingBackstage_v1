export const productionModuleName = 'production';

