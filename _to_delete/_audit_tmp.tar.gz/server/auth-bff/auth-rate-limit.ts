import type { IncomingMessage } from 'node:http';

const AUTH_RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
const AUTH_RATE_LIMIT_MAX_REQUESTS = 8;
const AUTH_RATE_LIMIT_MAX_ENTRIES = 10_000;

interface RateLimitEntry {
  resetAt: number;
  requestCount: number;
}

const entries = new Map<string, RateLimitEntry>();

const pruneExpiredEntries = (now: number): void => {
  entries.forEach((entry, key) => {
    if (entry.resetAt <= now) {
      entries.delete(key);
    }
  });

  while (entries.size >= AUTH_RATE_LIMIT_MAX_ENTRIES) {
    const oldestKey = entries.keys().next().value;

    if (oldestKey == null) {
      return;
    }

    entries.delete(oldestKey);
  }
};

const isLoopbackAddress = (value: string | undefined): boolean => {
  return value === '127.0.0.1' || value === '::1' || value === '::ffff:127.0.0.1';
};

const getClientAddress = (request: IncomingMessage): string => {
  const realIp = request.headers['x-real-ip'];

  if (isLoopbackAddress(request.socket.remoteAddress) && typeof realIp === 'string') {
    const normalized = realIp.trim();

    if (normalized) {
      return normalized;
    }
  }

  return request.socket.remoteAddress ?? 'unknown';
};

export const isAuthRateLimited = (request: IncomingMessage, route: string): boolean => {
  const now = Date.now();
  pruneExpiredEntries(now);
  const key = `${route}:${getClientAddress(request)}`;
  const current = entries.get(key);

  if (!current || current.resetAt <= now) {
    entries.set(key, {
      requestCount: 1,
      resetAt: now + AUTH_RATE_LIMIT_WINDOW_MS,
    });
    return false;
  }

  current.requestCount += 1;
  return current.requestCount > AUTH_RATE_LIMIT_MAX_REQUESTS;
};

export const clearAuthRateLimitForTests = (): void => {
  entries.clear();
};
