// @vitest-environment node

import { afterEach, describe, expect, it, vi } from 'vitest';

import { reserveAiUsage } from './usage-service.js';

describe('AI usage reservations', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('allows only one concurrent reservation when one use remains', async () => {
    const successfulLogIds: string[] = [];
    const fetchMock = vi.fn((url: string, init?: RequestInit) => {
      if (url.includes('/api/collections/ai_usage_limits/records?')) {
        return Promise.resolve(new Response(JSON.stringify({
          items: [{ enabled: true, monthly_limit: 1 }],
          totalPages: 1,
        }), { status: 200 }));
      }

      if (url.includes('/api/collections/ai_usage_logs/records?')) {
        return Promise.resolve(new Response(JSON.stringify({
          items: successfulLogIds.map((id) => ({ id })),
          totalPages: 1,
        }), { status: 200 }));
      }

      if (url.endsWith('/api/collections/ai_usage_logs/records')) {
        expect(init?.method).toBe('POST');
        const logId = `usage-${String(successfulLogIds.length + 1)}`;
        successfulLogIds.push(logId);
        return Promise.resolve(new Response(JSON.stringify({ id: logId }), { status: 200 }));
      }

      throw new Error(`Unexpected URL: ${url}`);
    });
    vi.stubGlobal('fetch', fetchMock);

    const results = await Promise.allSettled([
      reserveAiUsage('superuser-token', 'user-1', 'roast_analysis', '2026-07'),
      reserveAiUsage('superuser-token', 'user-1', 'roast_analysis', '2026-07'),
    ]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
    expect(successfulLogIds).toHaveLength(1);
  });
});
